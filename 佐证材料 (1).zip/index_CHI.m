function CHI_value = index_CHI(data, center, cluster_label)
ave_center = mean(center);
TRB = 0;
for i = 1:size(center,1)
    index = find(cluster_label == i);
    ni = size(index,1);
    TRB = TRB + ni*distfcm(center(i,:), ave_center);
end

dist = distfcm(center, data);
TRW = sum(sum(dist));
CHI_value = (TRB/(size(center,1)-1))/(TRW/(size(data,1)-size(center,1)));

