function [ X1 ] = normalizeX( X )
     X1=zeros(size(X));
     [N,L]=size(X);
     for k=1:L
         max_item=max(X(:,k));
         min_item=min(X(:,k));
         len=max_item-min_item;
         for i=1:N
             X1(i,k)=(X(i,k)-min_item)/len;
         end
     end

end

