function [ U,V,dx,W,ite ] = RDVWEKFCM( c,m,adre,maxitenum,e,sta,r,k )

    if endsWith(adre,'data_drybean.mat') 
        X=load(adre).dd;
    else 
        if endsWith(adre,".mat")
            X=load(adre).data;
        else
            X=load(adre);
        end
    end
     X1=normalizeX(X);
     n=size(X1,1);
     L=size(X1,2);
     V1=RLMAlgoNew(X,c,k);
     f=V1(1,:);
     
     W1=zeros(c,L);
     W1(:,:)=1/L;
     U1=UpdateU(m,X1,V1,W1,sta);
     weight=caculateW(X1,V1,1,U1);
     for ite=1:maxitenum
           W2=UpdateLW(weight,U1,m,X1,V1,r,sta);
           V2=UpdateV(weight,U1,X1,V1,m,sta,f,W2);
           U2=UpdateU(m,X1,V2,W2,sta);
           
           maxu=MaxU(U1,U2);
           if maxu<e
               break;
           else
               U1=U2;
               V1=V2;
               W1=W2;
           end
     end
     
     U=U2;
     V=V2;
     dx=[];
     for j=1:n
          [value,index]=max(U(:,j));
          dx=[dx;index];
     end
     W=W2;
end

function [weight] = caculateW(X, V, a, U)
    [N, ~] = size(X);
    [c, ~] = size(V);
    X2 = sum(X.^2, 2);
    V2 = sum(V.^2, 2);
    distance_sq = X2 + V2' - 2 * (X * V');

    G = exp(-a * distance_sq);

    weights_vector = sum(G .* U', 2) / c;

    weight = [];
    for j = 1:N
        weight = [weight, weights_vector(j)];
    end
end


function [u] = caculateu(i, j, m, X, V, W, sta)
    Xj = X(j, :); 
    distances = zeros(1, c); 
    for s = 1:c
        distances(s) = sum(W(s, :) .* (2 - 2 * exp(-((Xj - V(s, :)).^2) / (2 * sta^2))));
    end 
    d1 = distances(i);
    if d1 == 0
        u = 1;
        return;
    end
    ratio_sum = sum((d1 ./ distances).^(1 / (m - 1)));  
    u = 1 / ratio_sum;
end


function [U] = UpdateU(m, X, V, W, sta)

    c = size(V, 1);  
    N = size(X, 1);  
    L = size(X, 2);  
diff_squared = zeros(N, L, c);
for i = 1:c
    diff_squared(:, :, i) = (X - V(i, :)).^2;
end
gaussian_kernel = exp(-diff_squared / (2 * sta^2));
D = zeros(N, c);
for i = 1:c
    D(:, i) = sum(W(i, :) .* (2 - 2 * gaussian_kernel(:, :, i)), 2);
end
    U = zeros(c, N);
    for i = 1:c
        D_i = D(:, i);
        D_ratio = D_i ./ D; 
        D_ratio(D == 0) = Inf; 
        U(i, :) = 1 ./ sum(D_ratio.^(1 / (m - 1)), 2)';
    end
end


function [w] = caculateLW(i, l, weight, U, m, X, V, r, sta)
    [N, L] = size(X);
    U_power = U(i, :)'.^(m + 1); 
    GauseDist_l = 2 - 2 * exp(-((X(:, l) - V(i, l)).^2) / (2 * sta^2));
    GauseDist_all = 2 - 2 * exp(-((X - V(i, :)).^2) / (2 * sta^2));    
    d1 = exp(-r * sum(U_power .* GauseDist_l)); 
    d2 = sum(exp(-r * sum(U_power .* GauseDist_all, 1))); 
    w = d1 / d2;
end


function [W] = UpdateLW(weight, U, m, X, V, r, sta)
    [N, L] = size(X);    
    c = size(V, 1);      
    Umatrix = U.^(m + 1); 
    GauseDist_all = zeros(N, L, c); 
    for i = 1:c
        GauseDist_all(:, :, i) = 2 - 2 * exp(-((X - V(i, :)).^2) / (2 * sta^2));
    end
    d1 = zeros(c, L);
    for i = 1:c
        d1(i, :) = exp(-r * sum((Umatrix(i, :)') .* GauseDist_all(:, :, i), 1));
    end
    d2 = zeros(c, 1);
    for i = 1:c
        d2(i) = sum(exp(-r * sum((Umatrix(i, :)') .* GauseDist_all(:, :, i), 1)));
    end
    W = d1 ./ d2;
end


function [v] = caculatev(i, l, weight, U, X, V, m, sta, w)
    N = size(X, 1);
    GauseKernalValues = exp(-((X(:, l) - V(i, l)).^2) / (2 * sta^2));
    numerator = sum(weight(1, :)' .* (U(i, :)'.^m) .* GauseKernalValues .* X(:, l) .* w(i, l));
    denominator = sum(weight(1, :)' .* (U(i, :)'.^m) .* GauseKernalValues .* w(i, l));
    v = numerator / denominator;
end


function [V] = UpdateV(weight, U, X, V1, m, sta, f, w)
    [c, L] = size(V1); 
    N = size(X, 1);     
    GauseKernalMatrix = zeros(N, L, c);
    for i = 1:c
        GauseKernalMatrix(:, :, i) = exp(-((X - V1(i, :)).^2) / (2 * sta^2));
    end    
    Umatrix = U.^m;
    numerator = zeros(c, L);
    denominator = zeros(c, L);
    for i = 1:c
        numerator(i, :) = sum((weight' .* Umatrix(i, :)') .* GauseKernalMatrix(:, :, i) .* X, 1) .* w(i, :);   
        denominator(i, :) = sum((weight' .* Umatrix(i, :)') .* GauseKernalMatrix(:, :, i), 1) .* w(i, :);
    end 
    V = numerator ./ denominator;
    V(1, :) = f;
end


function [U] = InitialU(c, n)
    U = rand(c, n);
    U = U ./ sum(U, 1);
end


function [ret] = MaxU(U1, U2)
    ret = max(max(abs(U1 - U2)));
end

