function EARI_value = index_EARI(U, true_labels, cluster_labels)
n = size(U,1);
true_labels = true_labels - min(true_labels) + 1;
cluster_labels = cluster_labels - min(cluster_labels) + 1;
U_true = 0.3*ones(size(U,1), size(U,2)); 
for i = 1 : n
    U_true(i, true_labels(i)) = 0.7;  
end
a = 0;
b = 0;
c = 0;
d = 0;
tempV = zeros(1, size(U,2));
tempY = zeros(1, size(U,2));
tempX = zeros(1, size(U,2).^2);
tempZ = zeros(1, size(U,2).^2);
number = 0;
for j2 = 2 : n
    for j1 = 1 : j2-1      
       for k = 1 : size(U,2)
            tempV(1,k) = min(U(j1, k), U(j2, k));                
            tempY(1,k) = min(U_true(j1, k), U_true(j2, k));
       end     
        num = 1;
        for k1 = 1 : size(U,2)
             for k2 = 1 : size(U,2)
                  if (k1 ~= k2)
                        tempX(1, num) = min(U(j1, k1), U(j2, k2));
                        tempZ(1, num) = min(U_true(j1, k1), U_true(j2, k2));
                        num = num+1;
                  end
             end
        end  
        if (( true_labels(j1,1) ==  true_labels(j2,1) ) && ( cluster_labels(j1,1) ==  cluster_labels(j2,1) ))       
            a = a + min(max(tempV) , max(tempY)) ;    
        end
        
        if (( true_labels(j1,1) ==  true_labels(j2,1) ) && ( cluster_labels(j1,1) ~=  cluster_labels(j2,1) ))
             b = b + min(max(tempV) , max(tempZ)) ;                 
             number = number +1;
        end
        
        if (( true_labels(j1,1) ~=  true_labels(j2,1) ) && ( cluster_labels(j1,1) ==  cluster_labels(j2,1) ))
            c = c + min(max(tempX) , max(tempY)) ;  
             number = number +1;
        end
        
        if (( true_labels(j1,1) ~=  true_labels(j2,1) ) && ( cluster_labels(j1,1) ~=  cluster_labels(j2,1) ))          
            d = d+ min(max(tempX) , max(tempZ)) ; 
        end
        
    end
end
Up = a - (a+b)*(a+c)/(a+b+c+d);
Down = ((a+b)+(a+c))/2 - (a+b)*(a+c)/(a+b+c+d);
EARI_value = Up / Down;

clear U_true;
clear temp_X;
clear temp_Y;
clear temp_Z;
clear temp_V;