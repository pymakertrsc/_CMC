function [ V1 ] = renormalizeX( X,V )
      V1=zeros(size(V));
      [c,L]=size(V);
      for k=1:L
           max_item=max(X(:,k));
           min_item=min(X(:,k));
           len=max_item-min_item;
           for i=1:c
                 V1(i,k)=V(i,k)*len+min_item;
           end
      end
end

