function score = index_nmi(true_labels, cluster_labels)
n = length(true_labels);
true_labels = true_labels - min(true_labels) + 1;
cluster_labels = cluster_labels - min(cluster_labels) + 1;

cat = spconvert([(1:n)' true_labels ones(n,1)]);
cls = spconvert([(1:n)' cluster_labels ones(n,1)]);
cls = cls';
cmat = full(cls * cat);

n_i = sum(cmat, 1); 
n_j = sum(cmat, 2); 
[row, col] = size(cmat);
product = repmat(n_i, [row, 1]) .* repmat(n_j, [1, col]);
index = find(product > 0);
n = sum(cmat(:));
product(index) = (n*cmat(index)) ./ product(index);
index = find(product > 0);
product(index) = log(product(index));
product = cmat .* product;
score = sum(product(:));
index = find(n_i > 0);
n_i(index) = n_i(index) .* log(n_i(index)/n);
index = find(n_j > 0);
n_j(index) = n_j(index) .* log(n_j(index)/n);
denominator = sqrt(sum(n_i) * sum(n_j));
if denominator == 0
  score = 0;
else
  score = score / denominator;
end
