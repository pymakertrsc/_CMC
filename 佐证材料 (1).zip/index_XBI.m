function XBI_value=index_XBI(data, U, center,uExpoent)
    mf = U.^uExpoent;    
    dist = distfcm(data, center);
    Up = sum(sum(mf.*dist));           
    fprintf('Up�� %4f\n',Up);    
    Min_dis =  min(pdist(center));   
    fprintf('Min_dis�� %4f\n', Min_dis);
    Down = size(data, 1) * Min_dis;    
    XBI_value = Up / Down;     
    clear mf;    
    clear dist;    