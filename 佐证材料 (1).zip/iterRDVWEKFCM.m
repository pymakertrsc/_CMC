clc;
clear;

m=2.9897;sta =0.30483;r= 4.1307;k=3;

adre='.\data\data_iris.txt';
labeladre='.\data\label_iris.txt';


if endsWith(adre,'data_drybean.mat') 
    data=load(adre).dd;
else 
    if endsWith(adre,".mat")
        data=load(adre).data;
    else
        data=load(adre);
    end
end

if endsWith(labeladre,'.mat')
    true_label=load(labeladre).label;
else
    true_label=load(labeladre);
end
c=max(true_label);
maxitenum=1000;
e=0.001;

t1=clock;
[ U,V,dx,W,ite ]=RDVWEKFCM( c,m,adre,maxitenum,e,sta,r,k);
t2=clock;
time=etime(t2,t1);

V=renormalizeX(data,V);
dx_new=Resort(c,dx,true_label,data);
[Fscore,p,Recall] = compute_f(true_label,dx_new);
ACC_value=index_Acc(true_label, dx_new);
CHI_value=index_CHI(data,V,dx);
NMI_value=index_nmi(true_label,dx_new);
EARI_value = index_EARI(U', true_label, dx_new);
XBI_value=index_XBI(data,U',V,m);
