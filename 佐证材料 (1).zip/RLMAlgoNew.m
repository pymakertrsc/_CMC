function [V] = RLMAlgoNew(X, c, k)
    X1 = normalizeX(X);             
    Matrix = getDistanceMatrix(X1, 1); 
    r = getRadius(Matrix);          
    list = densityOrder(Matrix, r);  
    l = getPointDistance(Matrix, list); 
    centre = getCPoint(l, c, Matrix, k); 
    V = zeros(c, size(X, 2));       
    for i = 1:c
        V(i, :) = X1(centre(i, 1), :); 
    end
end

function [value] = checkDist(x, y, sta, r)

    d = GauseDist(x, y, sta);
    if d < r
        value = 1;
    else
        value = 0;
    end
end

function [Matrix] = getDistanceMatrix(X, sta)



    X2 = sum(X.^2, 2);
    distance_sq = X2 + X2' - 2 * (X * X'); 


    KernalMatrix = exp(-distance_sq / (2 * sta^2)); 


    Matrix = 2 - 2 * KernalMatrix;
end


function [value] = checkDisByDM(i, j, r, Matrix)
    d = Matrix(i, j); 
    if d < r
        value = 1;
    else
        value = 0;
    end
end

function [list] = densityOrder(Matrix, r)

    densityMatrix = Matrix <= r;

    densities = sum(densityMatrix, 2);

    list = [(1:size(Matrix, 1))', densities];

    list = sortrows(list, 2);
end


function [radius] = getRadius(Matrix)

    N = size(Matrix, 1);
    lownum = N * 0.01;  
    highnum = N * 0.02; 
    unique_distances = unique(Matrix(:)); 
    unique_distances = unique_distances(unique_distances > 0); 

    low = 1; 
    high = numel(unique_distances); 

  
    while low <= high
        mid = floor((low + high) / 2);
        radius = unique_distances(mid);

        density = sum(Matrix <= radius, 2); 
        meandensity = mean(density);       


        if meandensity >= lownum && meandensity <= highnum
            break; 
        elseif meandensity < lownum
            low = mid + 1; 
        else
            high = mid - 1; 
        end
    end
end




function [dis] = findLargePoint(list, i, Matrix)
    j = i + 1;
    dis = [];
    while j <= size(list, 1)
        dis = [dis, Matrix(i, j)];
        j = j + 1;    
    end
end

function [list3] = getPointDistance(Matrix, list)
    N = size(Matrix, 1);
    list2 = [];
    m = list(end, 1);
    maxdist = max(Matrix(m, :));
    for i = 1:N-1
        d = findLargePoint(list, i, Matrix);  
        dis = min(d);
        v = [list(i, 1), list(i, 2), dis * list(i, 2)];  
        list2 = [list2; v];
    end
    v = [m, list(end, 2), maxdist * list(end, 2)];
    list2 = [list2; v];
    list3 = sortrows(list2, -3);  
end

function [d] = getEnDistance(c, k, Matrix)
    maxdis = max(max(Matrix));
    d = maxdis / (c * k);  
end

function [centre] = getCPoint(list, c, Matrix, k)

    d = getEnDistance(c, k, Matrix);

    centre = [];

    N = size(list, 1);

    is_valid = true(N, 1);

    for index = 1:N
        if ~is_valid(index)
            continue;
        end

        centre = [centre; list(index, :)];

        distances = Matrix(list(:, 1), list(index, 1));

        is_valid = is_valid & (distances >= d);

        if size(centre, 1) >= c
            break;
        end
    end
end

