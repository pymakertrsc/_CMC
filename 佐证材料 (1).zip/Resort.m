function dx_new = Resort(cluster, dx, ground_truth, data)
   
    if nargin < 4
        error('��Ҫ4���������');
    end
    
    data_num = size(dx, 1);
    dimension = size(data, 2);
    unique_dx = unique(dx);
    if any(unique_dx > cluster)
        warning('dx��������cluster�ı�ǩֵ�����Զ�����');
        
        [~, ~, dx] = unique(dx);
        dx = reshape(dx, [], 1);
    end
    
    
    unique_gt = unique(ground_truth);
    if any(diff(unique_gt) > 1)
        [~, ~, ground_truth] = unique(ground_truth);
        ground_truth = reshape(ground_truth, [], 1);
    end

   
    x = zeros(cluster, dimension); 
    y = zeros(cluster, dimension);
    each_cluster_num = histcounts(dx, 1:(cluster+1)); 
    each_cluster_num_true = histcounts(ground_truth, 1:(cluster+1));

    
    for k = 1:cluster
        if each_cluster_num(k) > 0
            x(k, :) = mean(data(dx == k, :), 1);
        else
            warning(['Cluster ' num2str(k) ' �� dx ��û�����ݵ㡣']);
            x(k, :) = rand(1, dimension); 
        end

        if each_cluster_num_true(k) > 0
            y(k, :) = mean(data(ground_truth == k, :), 1);
        else
            warning(['Cluster ' num2str(k) ' �� ground_truth ��û�����ݵ㡣']);
            y(k, :) = rand(1, dimension);
        end
    end

   
    dis_center = pdist2(x, y, 'euclidean').^2;
    
    
    dis_center(~isfinite(dis_center)) = realmax;
    
    
    try
        [assignment, ~] = matchpairs(dis_center, max(dis_center(:)) * 2);
    catch
        
        assignment = [(1:cluster)', (1:cluster)'];
    end
    
    
    class_flag = 1:cluster;
    for j = 1:size(assignment, 1)
        if assignment(j,1) <= cluster && assignment(j,2) <= cluster
            class_flag(assignment(j,1)) = assignment(j,2);
        end
    end
    
    
    dx_new = zeros(data_num, 1);
    for i = 1:data_num
        if dx(i) > 0 && dx(i) <= numel(class_flag)
            dx_new(i) = class_flag(dx(i));
        else
            dx_new(i) = mode(class_flag); 
        end
    end
end