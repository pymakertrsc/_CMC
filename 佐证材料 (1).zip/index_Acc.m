function Acc_value = index_Acc(true_labels, cluster_labels)
n = length(true_labels);
a = 0;
for i = 1 : n
    if ( true_labels(i,1) ==  cluster_labels(i,1) ) 
        a = a+1.0;
    end
end
Acc_value = a / n; 